from setuptools import setup

setup(
    name='MyCinema',
    version='',
    packages=[''],
    url='',
    license='',
    author='',
    author_email='',
    description=''
)
